#!/bin/sh
echo "Launch Realtek AP Mode in /usr/rtl8723/ap.sh..."

#export LD_LIBRARY_PATH=/mnt/sdcard/

case "$1" in
  start)

echo -n "/etc/firmware/fw_bcmdhd_apsta.bin">/sys/module/bcm_wlan/parameters/firmware_path
insmod  /usr/modules/8723bs.ko 
sleep 1

ap_conf.sh

touch  /var/lib/misc/udhcpd.leases
/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -dd &

IPADDR="`/usr/local/bin/nvconf get wireless.ap.ipaddr`"
SUBNETMASK="`/usr/local/bin/nvconf get wireless.ap.subnetmask`"
sleep 1
ifconfig wlan0 $IPADDR netmask $SUBNETMASK
sleep 1
udhcpd -S /mnt/mtd3/udhcpd-ap.conf&

;;
  stop)
	echo " Kill all process of AP Mode"
	rmmod  bcm_wlan
	killall udhcpd
	killall hostapd
;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

