#!/bin/sh

#echo 0 > /proc/sys/vm/overcommit_memory

#btn_run &

#if [ ! -e /mnt/mtd3/user.conf ]; then
#cp -av /usr/system.conf /mnt/mtd3/user.conf
#sync
#fi



#test_start_cdc.sh


# CVISION Startup script 

# Source configuration files from /etc/profile.d
#for i in /etc/profile.d/CV??*.sh ; do
#    if [ -r "$i" ]; then
#        . $i
#    fi
#done


