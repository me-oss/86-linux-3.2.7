#!/bin/sh
echo "Launch AP6181 AP Mode in" ${PWD} "/sta.sh..."

#echo -n "/etc/firmware/fw_bcmdhd_ap.bin">/sys/module/bcm_wlan/parameters/firmware_path
insmod  /usr/modules/bcm_wlan_ap6181.ko firmware_path=/etc/firmware/fw_bcmdhd.bin nvram_path=/etc/firmware/nvram.txt
sleep 1

#wpa_supplicant -Dnl80211 -iwlan0 -c/etc/wpa_supplicant.conf -B
if [ ! -e /mnt/mtd3/wpa_supplicant.conf ]; then
cp /etc/wpa_supplicant.conf /mnt/mtd3/wpa_supplicant.conf
fi

killall -9 wpa_supplicant udhcpc udhcpd hostapd
/usr/local/bin/wpa_supplicant -B -iwlan0 -c /mnt/mtd3/wpa_supplicant.conf
udhcpc -i wlan0



