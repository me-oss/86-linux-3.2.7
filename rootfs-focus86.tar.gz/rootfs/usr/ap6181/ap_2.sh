#!/bin/sh
echo "Launch AP6181 AP Mode in /usr/ap6181_ap/ap.sh..."

#export LD_LIBRARY_PATH=/mnt/sdcard/

case "$1" in
  start)

echo -n "/etc/firmware/fw_bcmdhd_apsta.bin">/sys/module/bcm_wlan/parameters/firmware_path
insmod  /usr/modules/bcm_wlan_ap6181.ko 
sleep 1

ap_conf_2.sh

touch  /var/lib/misc/udhcpd.leases
/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -dd &

IPADDR="`nvconf get wireless.ap.ipaddr`"
SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
sleep 1
ifconfig wlan0 $IPADDR netmask $SUBNETMASK
sleep 1
udhcpd -S /mnt/mtd3/udhcpd-ap.conf&

;;
  stop)
	echo " Kill all process of AP Mode"
	rmmod  bcm_wlan
	killall udhcpd
	killall hostapd
;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

