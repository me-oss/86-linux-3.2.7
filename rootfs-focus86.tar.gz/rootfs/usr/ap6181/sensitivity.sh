#!/bin/sh                                                           
if [ "$1" == "h" ]||[ "$1" == "help" ]||[ "$1" == "" ]; then
echo ""
echo "*********Modulation**********"
echo "Parameter 1: channel"
echo "*****************************"
echo ""
exit 0
fi
channel=$1

wl down
wl band auto
wl mpc 0
wl country ALL
wl scansuppress 1
wl channel $channel
wl bi 65535
wl up
wl counters
