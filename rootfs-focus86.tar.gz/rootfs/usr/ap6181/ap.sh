#!/bin/sh
echo "Launch AP6181 AP Mode in /usr/ap6181_ap/ap.sh..."

#export LD_LIBRARY_PATH=/mnt/sdcard/

case "$1" in
  start)

echo -n "/etc/firmware/fw_bcmdhd_apsta.bin">/sys/module/bcm_wlan/parameters/firmware_path
insmod  /usr/modules/bcm_wlan_ap6181.ko 
sleep 1

### Start...change SSID bases on MAC address
SSID_PREFIX="CameraHD-"
NET_DEVICE="wlan0"
MODEL_ID="0066"

MACADDR_CUT=`cat "/sys/class/net/"$NET_DEVICE"/address" | awk '{gsub(/:/,"",$1); print $1}' | cut -c7-12`
NET_SSID=`echo -e "$SSID_PREFIX$MODEL_ID$MACADDR_CUT"`
echo $NET_SSID
SSID=`nvconf get wireless.ssid`
if [ $NET_SSID != $SSID ] && [ "$MACADDR_CUT" != "" ]; then
    SSID=$NET_SSID
    nvconf set wireless.ssid $SSID
    echo `nvconf get wireless.ssid`
fi

#Set MAC address to NVRAM
MACADDR=`cat "/sys/class/net/"$NET_DEVICE"/address" | awk '{gsub(/:/,"",$1); print $1}'`
if [ "$MACADDR" != "" ]; then
    echo "Setting Mac address $MACADDR"
    nvconf set devinfo.macaddr $MACADDR
fi
### Stop...change SSID bases on MAC address  
ap_conf.sh 

touch  /var/lib/misc/udhcpd.leases
/usr/sbin/hostapd /mnt/mtd3/hostapd.conf -dd &

IPADDR="`nvconf get wireless.ap.ipaddr`"
SUBNETMASK="`nvconf get wireless.ap.subnetmask`"
sleep 1
ifconfig wlan0 $IPADDR netmask $SUBNETMASK
sleep 1
udhcpd -S /mnt/mtd3/udhcpd-ap.conf&

;;
  stop)
	echo " Kill all process of AP Mode"
	rmmod  bcm_wlan
	killall udhcpd
	killall hostapd
	killall wpa_supplicant 
	killall udhcpc 
;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

