#!/bin/sh
echo "Launch device driver in /usr/rcInsDriver.sh..."

