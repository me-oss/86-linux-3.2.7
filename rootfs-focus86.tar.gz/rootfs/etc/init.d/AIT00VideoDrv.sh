#!/bin/sh
#
# Start the network....
#
echo "Enter AIT00VideoDrv shell script ..."

mem=`cat /proc/meminfo |grep MemTotal|tr -d ' '|cut -d':' -f 2|cut -d'k' -f 1`

#if [ $mem -lt 49000  ]; then
#insmod /usr/modules/ait-cam-codec.ko resv_dram_size=0x600000 resv_dram_base=0x2A00000
#else
#	insmod /usr/modules/ait-cam-codec.ko
#fi
insmod /usr/modules/ait-cam-codec.ko resv_dram_size=0x1200000
