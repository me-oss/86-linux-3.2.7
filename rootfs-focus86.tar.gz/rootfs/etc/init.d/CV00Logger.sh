#!/bin/sh
#echo 3000 > /proc/sys/vm/min_free_kbytes
echo 1 > /proc/sys/vm/panic_on_oom                                              
echo 5 > /proc/sys/kernel/panic                                                 
ulimit -c 2                                                                     
#mount /mnt/mtd7 /var/log
mkdir -p /var/log/debug
mkdir -p /var/lib/misc
touch /var/log/debug/messages
echo "12345678" > /var/lib/misc/udhcpd.leases
/sbin/syslogd -S -s1024 -l7 -O "/var/log/debug/messages"

cp /usr/zlog.conf /var/run/zlog.conf

