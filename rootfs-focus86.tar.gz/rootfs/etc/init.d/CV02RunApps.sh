#!/bin/sh
init_ble()
{
    #bring up the ble via Serial
    /usr/rtl8723/bluetooth_up.sh 

    cp /etc/bluetooth/main_stub.conf /tmp/main.conf 

    ble_name=$(/usr/local/bin/nvconf get wireless.ssid) 
    while [ -z $ble_name ] ;
    do 
        sleep 2; 
        ble_name=$(/usr/local/bin/nvconf get wireless.ssid)

    done

    echo "Name = $ble_name" >> /tmp/main.conf

    #Setup hci name
    /usr/bin/hciconfig hci0 name $ble_name   

    echo "Init BLE name: $ble_name" 

}

startff ()
{
     ipaddress=`ifconfig wlan0 | grep 'inet addr' | cut -d: -f2 | awk '{print $1}' || echo none` 
     while [ -z $ipaddress ] ;  
     do 
         sleep 2; 
         ipaddress=`ifconfig wlan0 | grep 'inet addr' | cut -d: -f2 | awk '{print $1}'`;
		 if [ -z $ipaddress ] ; then
         	ipaddress=`ifconfig wlan1 | grep 'inet addr' | cut -d: -f2 | awk '{print $1}'`;
		 fi

         echo "ipaddress is: $ipaddress"
     done

    #Phung: [DEBUG] start ffserver from sdcard 
#if [ -f "/mnt/sdcard/ffmpeg/new/ffserver" -a -f "/mnt/sdcard/ffmpeg/new/ffm.sh" -a ! -z $ipaddress ] ; then
#        echo "Start ffserver for local access ..." 
#        /mnt/sdcard/ffmpeg/new/ffserver -f /mnt/sdcard/ffmpeg/new/ffserver.conf & 
#        /mnt/sdcard/ffmpeg/new/ffm.sh 

     echo "Start rtspserver ..."
    #use rtspserver from usr/local/bin
     /usr/local/bin/rtspserver & 
     sleep 3
     /usr/local/bin/relaystreamer &

    #Start motion detection
    MOTION_MODE=`/usr/local/bin/nvconf get motion.mode`
    if [ $MOTION_MODE = "ON" ]; then
        /usr/local/bin/motiondetector &
    fi

}


echo "Starting CV02RunApps.sh"
resetfactory=`/bin/cat /proc/cmdline | /bin/grep resetfactory `
if [ -n "$resetfactory" ]; then
    /bin/sync; /bin/rm -f /mnt/mtd3/user.conf ; /bin/sync
fi
/usr/local/bin/cam_db



export PS1=root#
# turn off kernel log
echo 1 > /proc/sys/kernel/printk

echo "Press 'y' or 'Y' to enter test mode:"
read -n 1 -t 1 testmode
if [ "$testmode" = "Y" ] || [ "$testmode" = "y" ]; then
	echo "Enter test ftest mode"
	mount -o remount,rw -t jffs2 /dev/mtdblock4
    # create temporary file to mark this we are in ftest mode.
    touch /tmp/ftest_mode
else
	/usr/sbin/crond -c /usr/crond
	mkdir /tmp/storage
	mount -t tmpfs -o size=4M tmpfs /tmp/storage

	/usr/local/bin/hwmanager&
	/usr/local/bin/networkmanager&
	ifconfig lo up
	httpd -p 8080 -h /var/www/
	/usr/local/bin/fwupgrade -c &
	/usr/local/bin/httpserver &
	/usr/local/bin/ftpuploader http&
    /usr/local/bin/socmonitor &
    /usr/local/bin/blegateway &
    startff &
    init_ble &
fi
