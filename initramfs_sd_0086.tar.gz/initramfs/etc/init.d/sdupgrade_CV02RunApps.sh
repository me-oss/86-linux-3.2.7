#!/bin/sh
/usr/local/bin/sd_upgrade.sh
exit 0
