#!/bin/sh
echo "Starting CV02RunApps.sh"
echo "default-on" > /sys/devices/platform/leds-gpio.0/leds/LED-POWER/trigger 
echo "default-on" > /sys/devices/platform/leds-gpio.0/leds/LED-WIFI/trigger
# Blink LED1. blink LED2
echo "timer" > /sys/devices/platform/leds-gpio.0/leds/LED-POWER/trigger
echo 2001 > /sys/devices/platform/leds-gpio.0/leds/LED-POWER/delay_on
echo 2001 > /sys/devices/platform/leds-gpio.0/leds/LED-POWER/delay_off

/usr/local/bin/cam_db
#/usr/sbin/crond -c /usr/crond
#mount -t tmpfs -o size=4M tmpfs /tmp/storage
/usr/local/bin/fwupgrade -c
/usr/local/bin/hwmanager&
/usr/local/bin/networkmanager&
ifconfig lo up
httpd -p 8080 -h /var/www/

