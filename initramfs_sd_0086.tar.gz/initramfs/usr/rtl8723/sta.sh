#!/bin/sh
echo "Launch RTL8723 STA Mode in" ${PWD} "/sta.sh..."

insmod  /usr/modules/8723.ko
sleep 1
wpa_supplicant -Dnl80211 -iwlan0 -c/etc/wpa_supplicant.conf -B
udhcpc -iwlan0 -b



